function slowSum (a, b) {
    return new Promise((resolve, reject) => {
      const error = new Error('Random error 33% times');
      const fun = () => Math.random() < 0.33 ? reject(error) : resolve(a + b);
      setTimeout(fun, 1000);
    });
  }
  
  function task () {
    return new Promise((resolve, reject) => {
      slowSum(2, 3).then(function (value) {
        return slowSum(value, 2);
      }).then(function (value) {
        return slowSum(value, 6);
      }).then(function (value) {
        return resolve(value);
      }).catch(function (error) {
        return reject(error);
      });
    });
  }
  
  task()
    .then((value) => console.log('SUCCESS', value)) // 2 + 3 + 2 + 6 = 13
    .catch((error) => console.log('FAILURE', error)); // Random error