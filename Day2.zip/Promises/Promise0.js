function asyncFunction(bool) {
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        if(bool) {
          resolve(333);
        } else {
          reject('Promise rejected after 5 seconds');
        }
      }, 5000);   
    });
  }


  asyncFunction(true).then((result) => {
    console.log('Handle resolved result here', result);
 })
 .catch((err) => {
    console.log('Handle rejected error here', err);
 });


 asyncFunction(false).then((result) => {
    console.log('Handle resolved result here', result);
 })
 .catch((err) => {
    console.log('Handle rejected error here', err);
 });


 