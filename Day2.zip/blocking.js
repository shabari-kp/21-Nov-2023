 
var fs=require("fs");
var contents = fs.readFileSync('testfile.txt', 'utf8');
console.log("trying to do soemthing");
console.log(contents);
console.log("I am printed first"); // will be printed last


 
 


