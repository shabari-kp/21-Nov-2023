async function bar() {
    throw new Error('oh my god');
  }
  
  async function foo() {
    await bar();
  }
  
  async function main() {
    try {
      await foo();
    }
    catch(e) {
      console.error(`Something went wrong: ${e.message}`);
    }
  }
  
  main();