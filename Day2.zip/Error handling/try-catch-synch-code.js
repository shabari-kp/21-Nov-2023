

// catch the uncaught errors in this 
//synchronous code block
// try catch statements only work on synchronous code
try {
    // the synchronous code that we want to catch thrown errors on
    var err = new Error('something went wrong'); //
    throw err;

} 
catch (err) 
{
    // handle the error safely
    console.log(err.toString());
    //display entire error info
   // console.log(err);
}