// simple way to handle  errors - wrapping your code in  try .. catch

var fs=require('fs');

try
{
    fs.readFile("file.txt",function(contents)
    {
        console.log(contents);
   
    });
}
catch(e)
{
    console.log("error occured" + e);
}