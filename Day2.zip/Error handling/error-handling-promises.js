

function foo() {
    return bar(); // returning bar();
  }


  function bar() {
    return Promise.reject(new Error('oh my god'));
  }


  function main() {
    return foo().catch(e => {
      console.error(`Something went wrong: ${e.message}`);
    });
  }

  main();
  