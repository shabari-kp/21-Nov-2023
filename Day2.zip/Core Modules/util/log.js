var util = require('util');
util.log('sample message'); // 27 Apr 18:00:35 - sample message