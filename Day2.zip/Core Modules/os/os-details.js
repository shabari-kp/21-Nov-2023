var os = require('os'); //loadin the core module called as os
//no of CPUS 
os.cpus().forEach((cpu) => {
    console.log(cpu);
})

console.log(os.arch()); // 32 /64 / arm/

console.log(os.platform()); //wind / linux / mac

console.log(os.type()); // win / linux

console.log(os.totalmem()); // total mem - bytes

console.log(os.freemem()); // free mem - bytes

console.log(os.uptime()); // 

console.log(os.userInfo()); //domain related info