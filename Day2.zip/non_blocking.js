var fs = require('fs');
  fs.readFile('testfile.txt', 'utf8', function(err, data)
   {
      // called at a later time when the results are in
      console.log("trying to do soemthing while file read is in progress");
     console.log(data) // data var - response of reading the file
 });
  // readFile returns immediately and this line is reached right away

  console.log("I am printed first");